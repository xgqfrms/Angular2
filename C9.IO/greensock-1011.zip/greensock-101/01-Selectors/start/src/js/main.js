(function($) {
    
	// JS code goes here
	alert(1);
})(jQuery);