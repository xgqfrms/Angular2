(function($) {
    
	var img = $('img');

	// Simple Tween
	

})(jQuery);