# react-dom-diff
Demonstrate React component life-cycle and DOM diff algorithm.

View Demo: https://supnate.github.io/react-dom-diff/index.html
