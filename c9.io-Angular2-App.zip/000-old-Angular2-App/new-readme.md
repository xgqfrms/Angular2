#  angular-2 app

https://www.udemy.com/ultimate-angular-2/


2016.12.04


https://github.com/xgqfrms-GitHub/express


https://github.com/xgqfrms-GitHub/socket.io




# install -g 

```sh
$ npm i -g angular-cli  
``` 
# ng new Angular2-App
# https://github.com/angular/angular-cli

```sh
$ npm i -g typescript  
``` 
# tsc

```sh
$ npm i -g gulp
$ npm i -g browser-sync
$ npm i -g sass
$ npm i -g bootstrap
``` 

## install -S 
```sh
$ npm i -S express
$ npm i -S sockit.io
$ npm i -S async
$ npm i -S sass
$ npm i -S bootstrap
$ npm i -S angular-material
``` 

## install -D  
```sh
$ npm i -D browser-sync 

``` 

## no need any more

```sh
$ npm i -g angular-material
``` 
# 1.x
# https://material.angularjs.org/latest/
# https://www.npmjs.com/package/angular-material


```sh
$ npm install -g angular-cli
$ npm i -S @angular/material

```
# 2.x
# https://github.com/angular/material2/blob/master/GETTING_STARTED.md
# https://github.com/angular/material2
# https://material.angular.io/
 

