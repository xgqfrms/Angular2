#  angular-2 app

https://www.udemy.com/ultimate-angular-2/


2016.12.04


https://github.com/xgqfrms-GitHub/express


https://github.com/xgqfrms-GitHub/socket.io
















