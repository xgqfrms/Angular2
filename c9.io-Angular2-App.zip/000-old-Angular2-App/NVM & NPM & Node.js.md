# update

## nvm & node

```sh
$ nvm ls

$ nvm which node

$ nvm install v6.9.1

$ nvm use 6.9.1

$ nvm alias default 6.9.1
``` 

## npm 
```sh
$ npm i -g npm 

``` 

## angular-cli & typescript
```sh
$ npm i -g angular-cli  

$ npm i -g typescript

``` 

## update 

```sh
$ npm ls graceful-fs
$ npm i -g graceful-fs  

$ npm ls tough-cookie
$ npm i -g tough-cookie

$ npm ls minimatch
$ npm i -g minimatch

``` 